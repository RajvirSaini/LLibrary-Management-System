package com.empower.product.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

import javax.servlet.annotation.MultipartConfig;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.empower.product.entity.Book;
import com.empower.product.entity.BookStatus;
import com.empower.product.service.BookService;
@CrossOrigin("*")
@RestController
@RequestMapping("/book")
@MultipartConfig
public class BookController {

	@Autowired
	private BookService bookService;
	
	//Controller function For adding the book in the table
		
	public void storeImageInFile(Integer bookId, String imageStr) throws IOException
	{
		 byte[] data = Base64.decodeBase64(extractBase64Data(imageStr));
	        if (data != null) {
	            System.out.println("Converted to byte array");
	            
	            File f=new File("images\\"+bookId+".jpg");
	            FileOutputStream fos=new FileOutputStream(f);
	            fos.write(data);
	            fos.flush();
	            fos.close();
	            System.out.printf("Image %s is saved in %s",f.getName(),f.getAbsolutePath());
	        } else {
	            System.out.println("Invalid image data format.");
	        }

	}
	
	@PostMapping("/addbook")
	public ResponseEntity<Book> addBook(@RequestBody Book book) throws IOException
	{
		ResponseEntity<Book> re = null;
		BookStatus bookStatus = bookService.addBook(book);
		if(bookStatus.getBookStatus() == 0) {
			re = new ResponseEntity<Book>(book, HttpStatus.NOT_FOUND);
		}else {
			re = new ResponseEntity<Book>(book, HttpStatus.OK);
			storeImageInFile(book.getbookId(), book.getPicture());
		}
		
		return re;
	}
	
	//Controller function for updating the book
	
	@PostMapping("/updatebook")
	public ResponseEntity<Book> updateBook(@RequestBody Book book){
		ResponseEntity<Book> re = null;
		BookStatus bookStatus = bookService.updateBook(book);
		if(bookStatus.getBookStatus() == 0) {
			re = new ResponseEntity<Book>(book, HttpStatus.NOT_FOUND);
		}else {
			re = new ResponseEntity<Book>(book, HttpStatus.OK);
		}
		
		return re;
	}
	
	
	
	@GetMapping("/getbooks")
	public ResponseEntity<List<Book>> getAllBooks(){
		ResponseEntity<List<Book>> re = null;
		List<Book> books = bookService.getAllBooks();
		if(books.isEmpty()) {
			System.out.println("Book Not Found");
			re = new ResponseEntity<List<Book>>(books,HttpStatus.NOT_FOUND);
		}else {
		
			re = new ResponseEntity<List<Book>>(books,HttpStatus.OK);
		}
		return re;
	}
	
	@GetMapping("/getbookbyid/{bookid}")
	public ResponseEntity<BookStatus> getBookById(@PathVariable int bookid){
		ResponseEntity<BookStatus> re = null;
		BookStatus bookStatus = bookService.getBookById(bookid);
		if(bookStatus.getBookStatus()==0) {
			re = new ResponseEntity<BookStatus>(bookStatus,HttpStatus.NOT_FOUND);
		}else {
		
			re = new ResponseEntity<BookStatus>(bookStatus,HttpStatus.OK);
		}
		return re;
		
	}
	
	@DeleteMapping ("/deletebook/{bookid}")
	public ResponseEntity<BookStatus> deletebook(@PathVariable int bookid){
		ResponseEntity<BookStatus> re = null;
		BookStatus bookStatus = bookService.deleteBook(bookid);
		if(bookStatus.getBookStatus()==0) {
			re = new ResponseEntity<BookStatus>(bookStatus,HttpStatus.NOT_FOUND);
		}else {
		
			re = new ResponseEntity<BookStatus>(bookStatus,HttpStatus.OK);
		}
		return re;
		
	}
	
	@GetMapping("/getcategory/{category}")
	public ResponseEntity<List<Book>> getBooksByCategory(@PathVariable String category){
		ResponseEntity<List<Book>> re = null;
		List<Book> books = bookService.getBooksByCategory(category);
		if(books.isEmpty()) {
			re = new ResponseEntity<List<Book>>(books,HttpStatus.NOT_FOUND);
		}
		else {
			re = new ResponseEntity<List<Book>>(books,HttpStatus.OK);
		}
		return re;
	}
	
	@GetMapping("/categories")
	public ResponseEntity<List<String>> getCategories() {
	    ResponseEntity<List<String>> re = null;
	    List<String> categoryNames = bookService.getCategories(); 
	    if (categoryNames.isEmpty()) {
	        re = new ResponseEntity<List<String>>(categoryNames, HttpStatus.NOT_FOUND);
	    } else {
	        re = new ResponseEntity<List<String>>(categoryNames, HttpStatus.OK);
	    }
	    return re;
	}

	@GetMapping("/getbyauthor/{author}")
	public ResponseEntity<List<Book>> getBooksByAuthor(@PathVariable String author){
		ResponseEntity<List<Book>> re = null;
		List<Book> books = bookService.getBooksByAuthor(author);
		if(books.isEmpty()) {
			re = new ResponseEntity<List<Book>>(books,HttpStatus.NOT_FOUND);
		}
		else {
			re = new ResponseEntity<List<Book>>(books,HttpStatus.OK);
		}
		return re;
	}
	
	@GetMapping("/getbybook/{name}")
	public ResponseEntity<List<Book>> getBooksByName(@PathVariable String name){
		ResponseEntity<List<Book>> re;
	    List<Book> books;

	    if (name != null && !name.isEmpty()) {
	        // If a specific name is provided in the URL, search for books matching that name
	        books = bookService.getBooksByName(name);
	    } else {
	    	// If no name is provided, return an empty list of books
	        books = Collections.emptyList();
	    }

	    if (books.isEmpty()) {
	        re = new ResponseEntity<List<Book>>(books, HttpStatus.NOT_FOUND);
	    } else {
	        re = new ResponseEntity<List<Book>>(books, HttpStatus.OK);
	    }
	    return re;
	}
	
//	@PostMapping("/saveimage")
//	public ResponseEntity<String> saveImage(@RequestParam("picture") String picture, @RequestParam("bookId") Long bookId) {
//	    try {
//	        // Decode the base64 image string
//	        byte[] decodedImage = Base64.decodeBase64(extractBase64Data(picture));
//	        if (decodedImage != null) {
//	            System.out.println("Converted to image");
//	        } else {
//	            System.out.println("Invalid image data format.");
//	        }
//
//	        // Define the path to save the image
//	        String imagePath = "C:\\Users\\rajvi\\OneDrive\\Desktop\\react\\frontend\\public\\images\\" + bookId + ".jpeg";
//
//	        // Create the image file
//	        File imageFile = new File(imagePath);
//
//	        // Save the decoded image to the file
//	        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
//	            fos.write(decodedImage);
//	        }
//
//	        return new ResponseEntity<>("Image saved successfully.", HttpStatus.OK);
//	    } catch (Exception e) {
//	        return new ResponseEntity<>("Error saving the image: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
//	    }
//	}
//	
	public static String extractBase64Data(String picture) {
        int commaIndex = picture.indexOf(",");
        if (commaIndex != -1) {
            return picture.substring(commaIndex + 1);
        } else {
            return null;
        }
    }
}
