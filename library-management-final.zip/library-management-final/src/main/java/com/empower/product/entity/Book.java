/*
 This is Model for Book
 */

package com.empower.product.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "book")
public class Book {

	@Id
	//@GeneratedValue(strategy = GenerationType.AUTO)
	private int bookId;
	private String isbnNo;
	private String name;
	private String author;
	private String publisher;
	private String category;
	
	@Lob
	@Column(columnDefinition = "text")
	private String picture;
	
	@Temporal(TemporalType.DATE)@DateTimeFormat(pattern = "YYYY-MM-dd")
	private Date publishedDate;

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Book(int bookId, String isbnNo, String name, String author, String publisher, String category,
			String picture, Date publishedDate) {
		super();
		this.bookId = bookId;
		this.isbnNo = isbnNo;
		this.name = name;
		this.author = author;
		this.publisher = publisher;
		this.category = category;
		this.picture = picture;
		this.publishedDate = publishedDate;
	}

	public int getbookId() {
		return bookId;
	}
	
	public void setbookId(int id) {
		this.bookId = id;
	}
	public String getIsbnNo() {
		return isbnNo;
	}
	public void setIsbnNo(String isbnNo) {
		this.isbnNo = isbnNo;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public Date getPublishedDate() {
		return publishedDate;
	}
	public void setPublishedDate(Date publishedDate) {
		this.publishedDate = publishedDate;
	}
	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", isbnNo=" + isbnNo + ", name=" + name + ", author=" + author
				+ ", publisher=" + publisher + ", category=" + category + ", picture=" + picture + ", publishedDate="
				+ publishedDate + "]";
	}

}
